"use strict";

$(document).ready(function() {

    //event handler "Add to Cart" buttons k liye
    function addItem(evt) {

        var productId = $(this).attr('id');

        var route = '/products';

        if ( $(this).hasClass('prod_page') ) {
            route = '/products/' + productId;
        }
        var data = {
            productId: productId
        };

        $.post(route,
            data,
            function(evt) {
                alert("Item added to cart!");
        });
    }

    //event binding "Add to Cart" buttons k liye
    $('.add_to_cart').on('click', addItem);

    //event handler, Filters k liye at top of All Products page
    function showFilters(evt) {

        $('.filters').removeClass('hidden');
        $('.nofilters').addClass('hidden');
    }

    //event handler, Filters k liye at top of All Products page
    function hideFilters(evt) {

        $('.filters').addClass('hidden');
        $('.nofilters').removeClass('hidden');
    }

    //event binding, filters k liye at top of All Products page
    $('.showfilters').on('click', showFilters);
    $('.hidefilters').on('click', hideFilters);

    //
    function toggleFilter(evt) {

        if ($(this).hasClass('bright-category')) {
            $(this).removeClass('bright-category');
        } else {
            $(this).addClass('bright-category');
        }
    }

    $('.category').on('click', toggleFilter);

    });


